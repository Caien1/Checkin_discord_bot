
backgrounds={
   "level" : [   
                 "./res/backgrounds/orthogonal_plain.png"],
    "trees" : [
                 "./res/trees/image.png"
    ]
}